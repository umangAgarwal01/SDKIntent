//
//  iOSIntentSDK.h
//  iOSIntentSDK
//
//  Created by Trupay on 22/04/17.
//  Copyright © 2017 Trupay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iOSIntentSDK.
FOUNDATION_EXPORT double iOSIntentSDKVersionNumber;

//! Project version string for iOSIntentSDK.
FOUNDATION_EXPORT const unsigned char iOSIntentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSIntentSDK/PublicHeader.h>


